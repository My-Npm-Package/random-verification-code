import Test from './src/index'

export default Test